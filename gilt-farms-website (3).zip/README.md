
# Gilt Farms & Tech — Website (Gilt774)

This is a deploy-ready React (Vite) project scaffold for **Gilt Farms & Tech** (owner: Gilt774).
It includes:
- React + Vite setup
- Gallery that uses files from `/public/images/`
- Stripe checkout button (placeholder)
- Zapier webhook contact form (placeholder)
- Contact email pre-filled: giltfarmstech@gmail.com

## How to preview locally

1. Install dependencies:
```bash
cd gilt-farms-website
npm install
```

2. Create an `.env` file in the project root with these variables (or set in Vercel):
```
VITE_STRIPE_PUBLIC_KEY=pk_test_YOUR_KEY
VITE_ZAPPIER_WEBHOOK=https://hooks.zapier.com/hooks/catch/XXXXX/YYYYY/
```

3. Run the dev server:
```bash
npm run dev
```

Open the URL shown in the terminal (usually http://localhost:5173).

## Deploy to Vercel

1. Push this repo to GitHub under `Gilt774/gilt-farms-website`.
2. In Vercel, create a new project and link the GitHub repo.
3. Set the environment variables in Vercel (same as `.env` above).
4. Deploy — Vercel will auto-build and publish.

## Notes

- Replace the placeholder Stripe `price` ID and public key with your Stripe dashboard values.
- Replace the Zapier webhook with your Zapier catch hook URL to receive form submissions and trigger email responses.
- Add / replace real images in `/public/images/` — the gallery will display them automatically.

