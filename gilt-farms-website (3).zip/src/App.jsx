
import React, { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight, X, Mail, Phone, Facebook, ArrowUp, BatteryCharging, Cpu, Leaf, Sun } from "lucide-react";
import { loadStripe } from "@stripe/stripe-js";
import { motion } from "framer-motion";

// Replace with your Stripe public key in production or use environment variable
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY || "pk_test_REPLACE_ME");

export default function App() {
  const [selectedImage, setSelectedImage] = useState(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [formData, setFormData] = useState({ name: "", email: "giltfarmstech@gmail.com", message: "" });
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  const projects = [
    {
      id: 1,
      title: "Solar Installation & Inverter Systems",
      category: "Solar Energy",
      description:
        "Professional solar panel installation with safety protocols and optimal efficiency.",
      image:
        "/images/solar_sample.png",
      icon: <BatteryCharging />
    },
    {
      id: 2,
      title: "Smart Catfish Farming with IoT",
      category: "Aquaculture Tech",
      description:
        "AI-powered monitoring systems for water quality, feeding, and disease detection.",
      image:
        "/images/fish_sample.png",
      icon: <Cpu />
    },
    {
      id: 3,
      title: "Tech Repair & Maintenance",
      category: "Electronics",
      description:
        "Expert electrical and electronics repairs for all systems and smart devices.",
      image:
        "/images/tech_sample.png",
      icon: <Sun />
    },
    {
      id: 4,
      title: "Livestock & BSF Larvae Farming",
      category: "Agriculture",
      description:
        "Integrated farming solutions including pig farming and sustainable protein production.",
      image:
        "/images/livestock_sample.png",
      icon: <Leaf />
    },
  ];

  // local images from /public/images
  const localImages = [
    '/images/solar_sample.png',
    '/images/fish_sample.png',
    '/images/tech_sample.png',
    '/images/livestock_sample.png',
    '/images/team_sample.png'
  ];

  useEffect(() => {
    const handleScroll = () => setShowScrollTop(window.scrollY > 400);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const nextImage = () => {
    const newIndex = (currentIndex + 1) % projects.length;
    setCurrentIndex(newIndex);
    setSelectedImage(projects[newIndex]);
  };

  const prevImage = () => {
    const newIndex = (currentIndex - 1 + projects.length) % projects.length;
    setCurrentIndex(newIndex);
    setSelectedImage(projects[newIndex]);
  };

  const handleDonate = async () => {
    const stripe = await stripePromise;
    if (!stripe) {
      alert("Stripe not configured. Set VITE_STRIPE_PUBLIC_KEY in your environment.");
      return;
    }
    await stripe.redirectToCheckout({
      lineItems: [{ price: "price_REPLACE_ME", quantity: 1 }],
      mode: "payment",
      successUrl: window.location.origin + "?success=true",
      cancelUrl: window.location.origin + "?canceled=true",
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSending(true);
    try {
      // Send to Zapier webhook — set VITE_ZAPPIER_WEBHOOK in environment
      const webhook = import.meta.env.VITE_ZAPPIER_WEBHOOK || "";
      if (!webhook) {
        console.warn("No Zapier webhook configured. Message not sent.");
      } else {
        await fetch(webhook, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(formData),
        });
      }
      setSent(true);
      setFormData({ name: "", email: "giltfarmstech@gmail.com", message: "" });
    } catch (error) {
      console.error("Error sending message:", error);
      alert("Error sending message. Check console.");
    } finally {
      setSending(false);
    }
  };

  return (
    <div>
      <nav className="card" style={{display:"flex", justifyContent:"space-between", alignItems:"center"}}>
        <div style={{fontWeight:700, color:"#4ade80"}}>🟰 Gilt Farms & Tech</div>
        <div style={{display:"flex", gap:16}}>
          <a href="#services">Services</a>
          <a href="#gallery">Projects</a>
          <a href="#contact">Contact</a>
        </div>
      </nav>

      <header style={{padding:"3rem 1rem", textAlign:"center"}}>
        <h1 style={{fontSize:32, margin:0, background:"linear-gradient(90deg,#34d399,#06b6d4)", WebkitBackgroundClip:"text", color:"transparent"}}>Transforming Waste into Wealth</h1>
        <p style={{color:"#9ca3af"}}>Agriculture × Technology × Innovation</p>
        <div style={{display:"flex", gap:12, justifyContent:"center"}}>
          <a className="button" href="#contact">Get Started</a>
          <a className="card" href="#gallery">View Projects</a>
        </div>
      </header>

      <section id="services" style={{padding:"2rem 1rem"}}>
        <div className="container">
          <h2 style={{color:"#34d399"}}>Our Services</h2>
          <div style={{display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(240px,1fr))", gap:16}}>
            {projects.map((p)=>(
              <div key={p.id} className="card">
                <div style={{fontSize:24}}>{p.icon}</div>
                <h3 style={{color:"#86efac"}}>{p.title}</h3>
                <p style={{color:"#9ca3af"}}>{p.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="gallery" style={{padding:"2rem 1rem"}}>
        <div className="container">
          <h2 style={{color:"#34d399"}}>Projects & Gallery</h2>
          <div style={{display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(200px,1fr))", gap:12}}>
            {projects.map((project)=>(
              <div key={project.id} onClick={()=>{setSelectedImage(project); setCurrentIndex(project.id-1);}} style={{cursor:"pointer", borderRadius:12, overflow:"hidden"}}>
                <img src={project.image} alt={project.title} />
                <div style={{padding:8, background:"rgba(0,0,0,0.5)"}}>
                  <div style={{color:"#34d399"}}>{project.category}</div>
                  <div style={{fontWeight:700}}>{project.title}</div>
                </div>
              </div>
            ))}

            {localImages.map((src,i)=>(
              <div key={i} onClick={()=>setSelectedImage({image:src, title:"Gilt Farms Project", description:"Sustainable Tech & Agriculture", category:"Gallery"})} style={{cursor:"pointer", borderRadius:12, overflow:"hidden"}}>
                <img src={src} alt="Gilt Farms Project" />
                <div style={{padding:8, background:"rgba(0,0,0,0.5)"}}>
                  <div style={{color:"#34d399"}}>Gallery</div>
                  <div style={{fontWeight:700}}>Gilt Farms Project</div>
                </div>
              </div>
            ))}

          </div>
        </div>
      </section>

      {selectedImage && (
        <div style={{position:"fixed", inset:0, background:"rgba(0,0,0,0.9)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:50, padding:20}}>
          <div style={{maxWidth:900, width:"100%"}}>
            <button onClick={()=>setSelectedImage(null)} style={{position:"absolute", right:20, top:20, background:"transparent", border:"none", color:"#fff"}}><X /></button>
            <img src={selectedImage.image} alt={selectedImage.title} style={{width:"100%", borderRadius:12}} />
            <div style={{textAlign:"center", marginTop:12}}>
              <div style={{color:"#34d399", fontSize:14}}>{selectedImage.category}</div>
              <h3 style={{fontSize:22}}>{selectedImage.title}</h3>
              <p style={{color:"#9ca3af"}}>{selectedImage.description}</p>
            </div>
            <div style={{display:"flex", justifyContent:"space-between", marginTop:12}}>
              <button onClick={prevImage} className="button">Prev</button>
              <button onClick={nextImage} className="button">Next</button>
            </div>
          </div>
        </div>
      )}

      <section id="contact" style={{padding:"2rem 1rem"}}>
        <div className="container">
          <h2 style={{color:"#34d399"}}>Get In Touch</h2>
          <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:20}}>
            <form onSubmit={handleSubmit} className="card">
              <h3 style={{color:"#86efac"}}>Send us a Message</h3>
              <input required placeholder="Your Name" value={formData.name} onChange={(e)=>setFormData({...formData, name:e.target.value})} style={{width:"100%", padding:8, borderRadius:8, marginBottom:8}} />
              <input type="email" required placeholder="Your Email" value={formData.email} onChange={(e)=>setFormData({...formData, email:e.target.value})} style={{width:"100%", padding:8, borderRadius:8, marginBottom:8}} />
              <textarea required placeholder="Your Message" value={formData.message} onChange={(e)=>setFormData({...formData, message:e.target.value})} rows={4} style={{width:"100%", padding:8, borderRadius:8, marginBottom:8}} />
              <button type="submit" className="button">{sending ? "Sending..." : "Send Message"}</button>
              {sent && <div style={{color:"#34d399", marginTop:8}}>✅ Message sent! We'll respond soon.</div>}
            </form>

            <div className="card" style={{display:"flex", flexDirection:"column", justifyContent:"center", alignItems:"center"}}>
              <h3 style={{color:"#86efac"}}>Support Our Mission</h3>
              <p style={{color:"#9ca3af"}}>Help us continue transforming agriculture with innovative technology solutions.</p>
              <button onClick={handleDonate} className="button" style={{marginTop:12}}>💳 Donate via Stripe</button>
            </div>
          </div>
        </div>
      </section>

      <footer style={{padding:20, textAlign:"center", borderTop:"1px solid rgba(34,197,94,0.12)"}}>
        <div>© {new Date().getFullYear()} giltfarmstech.com | Built for <strong style={{color:"#34d399"}}>Gilt774</strong></div>
        <div style={{color:"#9ca3af"}}>Agriculture × Technology × Innovation</div>
      </footer>
    </div>
  );
}
